# SellMyDoll.com

A UK brokerage for pre-owned dolls, built with Next.js 15 and Supabase, hosted on Netlify.
The site sells **used dolls only**. New dolls appear only as affiliate links on `/buy-new`.

## Run locally
```bash
npm install
cp .env.example .env.local   # leave it blank to run on sample listings
npm run dev                  # http://localhost:3000
```
If Supabase isn't configured, the site shows `SAMPLE_LISTINGS` from `lib/data.ts`. As soon as the Supabase keys are set, it shows only real, approved listings.

## What's included
| Area | Where |
|---|---|
| Home, browse (filters for brand, material, height, body type, condition, price and region), listing pages | `app/page.tsx`, `app/browse`, `app/listing/[id]` |
| Sell flow: package choice, valuation hint, photo upload, declarations | `components/SellForm.tsx`, `app/api/listing` |
| Enquiries passed on anonymously, report-a-listing, waitlist | `app/api/enquiry`, `app/api/report`, `app/api/waitlist` |
| Moderation: approve (sends payment link), mark paid (goes live), reject (with reason) | `app/admin`, `app/api/admin` (protected by HTTP basic auth in `middleware.ts`) |
| Packages and prices | `TIERS` in `lib/data.ts` |
| Affiliate partners for new dolls | `AFFILIATE_PARTNERS` in `lib/data.ts` (set `active: true` and add the URL) |
| Policies | `lib/legal.ts` → `/legal/*` |
| Database schema, RLS and storage bucket | `supabase/migrations/001_init.sql` |

## Listing lifecycle
`pending` → (admin approves, seller is emailed a payment link) → `awaiting_payment` → (admin marks paid) → `approved` (live) → `sold` / `expired`.
Sellers are never charged for a listing you reject.

## Launch checklist
1. **Buy sellmydoll.com.** Add it to Netlify and set `NEXT_PUBLIC_SITE_URL`.
2. **Company admin:** register the new Ltd, register with the ICO (data protection fee), then fill the company name, number and address into `lib/legal.ts`. Have a solicitor review the terms and privacy notice.
3. **Supabase:** create a project in the London (eu-west-2) region, run `001_init.sql`, then set the three Supabase env vars.
4. **Payments:** open an account with an adult-friendly processor such as CCBill, Segpay or Verotel. Stripe, PayPal and Shopify Payments generally won't accept adult goods. Create three hosted payment links and set `PAYMENT_LINK_*`. Later, a payment webhook can mark listings as paid automatically.
5. **Brokered sales and buyer money:** if you take buyers' payments and pass them on to sellers, take advice on whether you fall under the FCA's commercial agent exclusion, or use a marketplace payment product that holds funds for you. Until that's settled, confirm the buyer has paid the seller before handover rather than holding the money yourself.
6. **Courier:** agree a rate with a discreet courier for 30–45 kg boxed items, mainland UK. Your £150 delivery margin depends on that rate.
7. **Email:** set up Brevo transactional email with SPF, DKIM and DMARC on sellmydoll.com, then set `BREVO_API_KEY` and `NOTIFY_EMAIL`.
8. **Admin:** set `ADMIN_USER` and a strong `ADMIN_PASSWORD`.
9. **Netlify:** set the env vars and deploy (`netlify.toml` is included).
10. **Seed listings:** list the first sellers from the opt-in campaign as Brokered, at the founding-seller price, so the site launches with real stock.

## Moderation rules (enforced in the form, the API and the database)
- Full-body dolls must be at least 150 cm (database constraint `full_doll_min_height`).
- All five seller declarations are required.
- 3–10 photos (JPG, PNG or WebP, 8 MB each at most).
- **A person reviews every listing.** Reject anything with a childlike appearance, whatever its stated height. Keep the record and report it to the police or the IWF where appropriate.
