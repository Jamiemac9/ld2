import Link from 'next/link';
import ListingCard from '@/components/ListingCard';
import Tiers from '@/components/Tiers';
import { getListings } from '@/lib/store';

export const revalidate = 300;

export default async function Home() {
  const listings = (await getListings()).slice(0, 4);
  return (
    <>
      <section className="hero">
        <div className="wrap hero-grid">
          <div>
            <span className="eyebrow">UK pre-owned doll brokerage</span>
            <h1>Sell your doll privately, to a buyer we have checked.</h1>
            <p className="lead">Your doll stays with you until it sells. Your details are never shown publicly. You pay nothing until we have approved your listing.</p>
            <div className="cta">
              <Link href="/sell" className="btn accent">Value &amp; list my doll</Link>
              <Link href="/browse" className="btn ghost">Browse pre-owned</Link>
            </div>
          </div>
          <div className="hero-card">
            <ul>
              <li><span className="tick">✓</span><div><b>Every listing checked by a person</b><br /><span className="muted small">We read every listing and look at every photo before anything goes live.</span></div></li>
              <li><span className="tick">✓</span><div><b>Your details stay private</b><br /><span className="muted small">Buyers contact you through us, so they never see your name, email, number or address.</span></div></li>
              <li><span className="tick">✓</span><div><b>Pay only once you're approved</b><br /><span className="muted small">If we can't list your doll, you pay nothing.</span></div></li>
              <li><span className="tick">✓</span><div><b>Discreet collection across the UK</b><br /><span className="muted small">With the delivery package, we collect your doll and ship it to the buyer in an unmarked box.</span></div></li>
            </ul>
          </div>
        </div>
      </section>

      <div className="strip">
        <div className="wrap">
          <div><b>Pre-owned only</b>We don't stock new dolls</div>
          <div><b>From £49</b>One fee, no commission</div>
          <div><b>UK-wide</b>Collection from mainland UK</div>
          <div><b>Private</b>Unmarked boxes, no names on the label</div>
        </div>
      </div>

      <section>
        <div className="wrap">
          <span className="eyebrow">How it works</span>
          <h2>From your spare room to a new owner in four steps</h2>
          <div className="steps" style={{ marginTop: 28 }}>
            <div className="step"><h3>Tell us about your doll</h3><p className="muted small">Fill in a two-minute form with the brand, size, condition and your photos.</p></div>
            <div className="step"><h3>We check it</h3><p className="muted small">We review your listing, usually within 24 hours, and suggest a fair price.</p></div>
            <div className="step"><h3>Pay and go live</h3><p className="muted small">Once you're approved, pay the one-off fee and your listing goes live.</p></div>
            <div className="step"><h3>Sell privately</h3><p className="muted small">We pass on genuine enquiries. With a brokered sale, we handle everything.</p></div>
          </div>
        </div>
      </section>

      <section style={{ paddingTop: 0 }}>
        <div className="wrap">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'end', gap: 20, flexWrap: 'wrap', marginBottom: 24 }}>
            <div><span className="eyebrow">Just listed</span><h2 style={{ margin: 0 }}>Pre-owned dolls for sale</h2></div>
            <Link href="/browse" className="btn ghost">See all listings</Link>
          </div>
          <div className="grid">{listings.map((l) => <ListingCard key={l.id} l={l} />)}</div>
        </div>
      </section>

      <section className="dark">
        <div className="wrap">
          <div style={{ maxWidth: 640, marginBottom: 36 }}>
            <span className="eyebrow">Pricing</span>
            <h2>One fee, no commission on your sale</h2>
            <p className="muted">Choose how much you want us to handle. Whatever price you sell for, you keep all of it.</p>
          </div>
          <div style={{ color: 'var(--ink)' }}><Tiers /></div>
        </div>
      </section>

      <section>
        <div className="wrap split">
          <div>
            <span className="eyebrow">Our standards</span>
            <h2>We turn down listings that don't meet our standards</h2>
            <p className="muted">Every doll has to be cleaned and sanitised before it's listed. Any removable insert must be new and sealed, or left out of the sale. Full-body dolls must be at least 150 cm tall and have a clearly adult appearance. We refuse any listing that doesn't meet these standards and report it where the law requires.</p>
            <Link href="/legal/listing-standards" className="btn ghost">Read our listing standards</Link>
          </div>
          <div className="panel">
            <h3>Thinking about buying new?</h3>
            <p className="muted">We sell pre-owned dolls only. If nothing here suits you, our partner retailers sell new dolls, and we may earn a small commission if you buy through our links.</p>
            <Link href="/buy-new" className="btn">See new-doll partners</Link>
          </div>
        </div>
      </section>
    </>
  );
}
