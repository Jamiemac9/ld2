import { getListings } from '@/lib/store';
import { LEGAL } from '@/lib/legal';
export default async function sitemap() {
  const base = process.env.NEXT_PUBLIC_SITE_URL || 'https://sellmydoll.com';
  const pages = ['', '/browse', '/sell', '/pricing', '/how-it-works', '/buy-new', '/faq', '/contact', ...Object.keys(LEGAL).map((s) => `/legal/${s}`)];
  const listings = await getListings();
  return [...pages.map((p) => ({ url: base + p })), ...listings.map((l) => ({ url: `${base}/listing/${l.id}` }))];
}
