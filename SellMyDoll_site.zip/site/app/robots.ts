export default function robots() {
  return { rules: [{ userAgent: '*', allow: '/', disallow: ['/admin', '/api', '/report'] }], sitemap: `${process.env.NEXT_PUBLIC_SITE_URL || 'https://sellmydoll.com'}/sitemap.xml` };
}
